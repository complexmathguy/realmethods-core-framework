/************************************************************************ 
 * Copyright 2012-2017 realMethods, Inc.  All rights reserved.
 * This software is the proprietary information of realMethods Inc.
 * Use is subject to license terms.
 *************************************************************************/


package com.framework.common.context;

//***************************
//Imports
//***************************

/**
 * Common interface for all context definitions, used for identify purposes only 
 */
public interface IFrameworkContext extends java.io.Serializable
{
}

/*
 * Change Log:
 * $Log$
 */



